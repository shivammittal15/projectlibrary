﻿using Microsoft.AspNetCore.Mvc;
using StudentManagement.Models;
using System;
using System.Collections.Generic;

namespace StudentManagement.Controllers
{
    public class ResourceController : Controller
    {
        public IActionResult ResourceDetails(int id)
        {
            List<Resource> resourcelist = new Resource().GetResurceLinkedData(id);
            ViewBag.StudentId = id;
            return View(resourcelist);
        }
        public IActionResult ResourceList()
        {
            List<Resource> resourcelist = new Resource().GetResurceData();
            return View(resourcelist);
        }
        public IActionResult Save(Resource resource = null)
        {
            if (resource == null || resource.ID < 1)
            {
                resource.ID = resource.GetLatestID();
                return View(resource);
            }
            if(resource.StartDate == DateTime.MinValue) {
            resource.StartDate = DateTime.Now;
            }
          if(resource.EndDate == DateTime.MinValue) {
            resource.EndDate = DateTime.Now;
            }
            resource.Save();
            return RedirectToAction("ResourceList");
        }
        public IActionResult Delete(int id)
        {
            new Resource().DeleteResourceData(id);
            return RedirectToAction("ResourceList");
        }
        public IActionResult Edit(int id)
        {
            Resource obj = new Resource().GetSingleResourceData(id);
            return View("Save", obj);
        }
        public IActionResult Create(int ID)
        {
            HomeModel data = new HomeModel
            {
                AvailableResources = new Resource().GetResurceRemainingData(),
                studentId = ID
            };
            return View(data);
        }
        public IActionResult Remove(int id, int studentid)
        {
            new Student().Delinkresource(id, studentid);
            return RedirectToAction("ResourceDetails", new { id = studentid });
        }
    }
}
